DefineMacro("EoneNumObs", e1_data$num_obs)
