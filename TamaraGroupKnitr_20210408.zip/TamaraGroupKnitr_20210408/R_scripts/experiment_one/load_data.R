e1_data <- LoadIntoEnvironment(file.path(data_path, "experiment_one_data.Rdata"))
