DefineMacro("ETwoNumObs", e2_data$num_obs)
DefineMacro("ETwoBeta", e2_data$beta)
