e2_data <- LoadIntoEnvironment(
  file.path(data_path, "experiment_two_data.Rdata"))
